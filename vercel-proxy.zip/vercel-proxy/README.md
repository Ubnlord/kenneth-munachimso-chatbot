# Kenneth Munachimso AI Proxy (Vercel)

## How to deploy

1. Go to https://vercel.com and sign up / log in
2. Click "Add New..." → "Project"
3. Choose "Upload" or import a GitHub repo
4. Upload the files inside this folder (api/, package.json, vercel.json)
5. After first deploy, go to Project Settings → Environment Variables
6. Add a new variable:
   - Name:  XAI_API_KEY
   - Value: your xAI API key (starts with xai-...)
7. Redeploy the project
8. Copy your project URL (example: https://kenneth-ai-proxy.vercel.app)
9. Open your chatbot → Settings → paste the URL → Save

That’s it.
